const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.xkYZs0_M.mjs').then(interopDefault),
  "pages/events/[id].vue": () => import('./_nuxt/_id_-styles.zCNHndZN.mjs').then(interopDefault),
  "pages/events/index.vue": () => import('./_nuxt/index-styles.OAU97pTz.mjs').then(interopDefault),
  "pages/auth/signin.vue": () => import('./_nuxt/signin-styles.Vbg8GLzy.mjs').then(interopDefault),
  "pages/auth/signup.vue": () => import('./_nuxt/signup-styles.iKaNuLxA.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.XRz1-5H_.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.vMIeuOQq.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.wRZntmTE.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
