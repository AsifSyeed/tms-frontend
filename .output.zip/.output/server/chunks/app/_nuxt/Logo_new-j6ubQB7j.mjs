import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("Logo_new.lsCfgemm.png");

export { _imports_0 as _ };
//# sourceMappingURL=Logo_new-j6ubQB7j.mjs.map
