import script from './menubar.esm-kSwnsfr6.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-qBDOgvys.mjs';
import { _ as __nuxt_component_2 } from './Button-0cjZoXcA.mjs';
import { n as navigateTo } from '../server.mjs';
import { ref, withCtx, createVNode, createTextVNode, toDisplayString, unref, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './Logo_new-j6ubQB7j.mjs';
import { i as isAuthenticatedState } from './state-J8LcOMay.mjs';
import './index.esm-V3p-V6tp.mjs';
import './baseicon.esm-NKYSbA-x.mjs';
import './basecomponent.esm-Ns9gWp1a.mjs';
import './index.esm-5TKGS5vn.mjs';
import './index.esm-Hu-4-Cj5.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './button.esm-yqH_VtjC.mjs';
import './badge.esm-qf1cCx9u.mjs';
import './index.esm-6y1nd5QS.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    const isAuthenticated = isAuthenticatedState();
    const items = ref([
      {
        label: "Home",
        action: "/"
      },
      {
        label: "Events",
        action: "/events"
      }
    ]);
    const signIn = () => {
      navigateTo("/auth/signin");
    };
    const logOut = () => {
      navigateTo("/auth/logout");
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Menubar = script;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_GlobalButton = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="card max-w-screen lg:w-9 sm:w-full pt-2 mx-auto">`);
      _push(ssrRenderComponent(_component_Menubar, {
        model: items.value,
        class: "bg-gray-800 mx-2 mb-2 border-none"
      }, {
        start: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="" class="h-3rem px-3 py-1"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "",
                class: "h-3rem px-3 py-1"
              })
            ];
          }
        }),
        item: withCtx(({ item }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: `${item.action}`,
              class: "mx-2 text-white"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(item.label)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(item.label), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_NuxtLink, {
                to: `${item.action}`,
                class: "mx-2 text-white"
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(item.label), 1)
                ]),
                _: 2
              }, 1032, ["to"])
            ];
          }
        }),
        end: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex align-items-left gap-2 pr-2"${_scopeId}>`);
            if (unref(isAuthenticated)) {
              _push2(`<div class="mr-2 text-white"${_scopeId}>Hello, Samin</div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(isAuthenticated)) {
              _push2(ssrRenderComponent(_component_GlobalButton, {
                title: "Log Out",
                class: "",
                onButtonTapped: logOut
              }, null, _parent2, _scopeId));
            } else {
              _push2(ssrRenderComponent(_component_GlobalButton, {
                title: "Sign In",
                class: "",
                onButtonTapped: signIn
              }, null, _parent2, _scopeId));
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex align-items-left gap-2 pr-2" }, [
                unref(isAuthenticated) ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "mr-2 text-white"
                }, "Hello, Samin")) : createCommentVNode("", true),
                unref(isAuthenticated) ? (openBlock(), createBlock(_component_GlobalButton, {
                  key: 1,
                  title: "Log Out",
                  class: "",
                  onButtonTapped: logOut
                })) : (openBlock(), createBlock(_component_GlobalButton, {
                  key: 2,
                  title: "Sign In",
                  class: "",
                  onButtonTapped: signIn
                }))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-p_v73r8i.mjs.map
