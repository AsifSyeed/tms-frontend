import script from './card.esm-Bk1r8Hp9.mjs';
import { _ as __nuxt_component_2 } from './Button-0cjZoXcA.mjs';
import { u as useFetch } from './fetch-h0nM2QUj.mjs';
import { n as navigateTo } from '../server.mjs';
import { withAsyncContext, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import './basecomponent.esm-Ns9gWp1a.mjs';
import './button.esm-yqH_VtjC.mjs';
import './badge.esm-qf1cCx9u.mjs';
import './index.esm-6y1nd5QS.mjs';
import './baseicon.esm-NKYSbA-x.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './ssr-OTkz--jL.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    function getTime(input) {
      var date = new Date(input.replace(/ /g, "T"));
      return [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
      ][date.getMonth()] + " " + date.getDate() + ", " + date.getFullYear() + ", " + date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    }
    const { data: events } = ([__temp, __restore] = withAsyncContext(() => useFetch("http://ec2-18-205-246-50.compute-1.amazonaws.com:8080/api/v1/event/all", "$E5yYdkStkR")), __temp = await __temp, __restore(), __temp);
    console.log(events);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Card = script;
      const _component_GlobalButton = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)}><div class="mx-auto w-full px-4 sm:px-2 lg:px-4"><div class="mx-auto max-w-2xl lg:max-w-none py-2"><h2 class="text-2xl font-bold text-white">Events</h2><div class="grid"><!--[-->`);
      ssrRenderList(unref(events).data, (event) => {
        _push(`<div class="lg:col-4 sm:col-12 p-4">`);
        _push(ssrRenderComponent(_component_Card, {
          style: { "overflow": "hidden" },
          class: "bg-gray-800"
        }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img alt="user header" src="https://images.unsplash.com/photo-1604514288114-3851479df2f2?q=80&amp;w=2071&amp;auto=format&amp;fit=crop&amp;ixlib=rb-4.0.3&amp;ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="h-15rem w-full overflow-hidden"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  alt: "user header",
                  src: "https://images.unsplash.com/photo-1604514288114-3851479df2f2?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                  class: "h-15rem w-full overflow-hidden"
                })
              ];
            }
          }),
          title: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="text-white"${_scopeId}>${ssrInterpolate(event.eventName)}</div>`);
            } else {
              return [
                createVNode("div", { class: "text-white" }, toDisplayString(event.eventName), 1)
              ];
            }
          }),
          subtitle: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="text-white"${_scopeId}>${ssrInterpolate(getTime(event.eventStartDate))}</div>`);
            } else {
              return [
                createVNode("div", { class: "text-white" }, toDisplayString(getTime(event.eventStartDate)), 1)
              ];
            }
          }),
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2)
              ;
            else {
              return [];
            }
          }),
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex gap-3 mt-1"${_scopeId}>`);
              if (event.eventAvailableTickets > 0) {
                _push2(ssrRenderComponent(_component_GlobalButton, {
                  title: "Check Event",
                  class: "w-full",
                  onButtonTapped: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/events/" + event.eventId)
                }, null, _parent2, _scopeId));
              } else {
                _push2(ssrRenderComponent(_component_GlobalButton, {
                  title: "Sold Out",
                  class: "w-full soldOutButton",
                  disabled: true,
                  onButtonTapped: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/events/" + event.eventId)
                }, null, _parent2, _scopeId));
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex gap-3 mt-1" }, [
                  event.eventAvailableTickets > 0 ? (openBlock(), createBlock(_component_GlobalButton, {
                    key: 0,
                    title: "Check Event",
                    class: "w-full",
                    onButtonTapped: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/events/" + event.eventId)
                  }, null, 8, ["onButtonTapped"])) : (openBlock(), createBlock(_component_GlobalButton, {
                    key: 1,
                    title: "Sold Out",
                    class: "w-full soldOutButton",
                    disabled: true,
                    onButtonTapped: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/events/" + event.eventId)
                  }, null, 8, ["onButtonTapped"]))
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/events/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-6sMKZpTE.mjs.map
