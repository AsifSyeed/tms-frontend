const _id__vue_vue_type_style_index_0_lang = ".centered{left:50%;position:absolute;top:50%;transform:translate(-50%,-50%)}.container{color:#fff;position:relative;text-align:center}.p-fieldset .p-fieldset-legend{background:#fbaf44!important;color:#000!important}.p-fieldset .p-fieldset-content{padding-bottom:2rem;padding-top:2rem}";

const _id_Styles_zCNHndZN = [_id__vue_vue_type_style_index_0_lang, _id__vue_vue_type_style_index_0_lang];

export { _id_Styles_zCNHndZN as default };
//# sourceMappingURL=_id_-styles.zCNHndZN.mjs.map
