import script from './fieldset.esm-_4F8iH4N.mjs';
import script$1 from './card.esm-Bk1r8Hp9.mjs';
import { _ as __nuxt_component_2 } from './Button-0cjZoXcA.mjs';
import { u as useRoute, n as navigateTo } from '../server.mjs';
import { u as useFetch } from './fetch-h0nM2QUj.mjs';
import { withAsyncContext, ref, mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrInterpolate, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import './index.esm-7PAEpwBM.mjs';
import './baseicon.esm-NKYSbA-x.mjs';
import './basecomponent.esm-Ns9gWp1a.mjs';
import './index.esm-D_EowQ68.mjs';
import './button.esm-yqH_VtjC.mjs';
import './badge.esm-qf1cCx9u.mjs';
import './index.esm-6y1nd5QS.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './ssr-OTkz--jL.mjs';

const _sfc_main = {
  __name: "[id]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { id } = useRoute().params;
    const { data: events } = ([__temp, __restore] = withAsyncContext(() => useFetch("http://ec2-18-205-246-50.compute-1.amazonaws.com:8080/api/v1/event/all", "$SFRTai2keR")), __temp = await __temp, __restore(), __temp);
    let selectedEvent = ref();
    if (id !== null) {
      console.log(id);
      selectedEvent.value = events.value.data.filter((e) => e.eventId === id)[0];
      console.log(selectedEvent);
    }
    function getDate(input) {
      var date = new Date(input.replace(/ /g, "T"));
      return [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
      ][date.getMonth()] + " " + date.getDate() + ", " + date.getFullYear();
    }
    function getTime(input) {
      var date = new Date(input.replace(/ /g, "T"));
      return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Fieldset = script;
      const _component_Card = script$1;
      const _component_GlobalButton = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "text-white" }, _attrs))}><div class="px-2 mt-6"><div class="w-12 h-22rem border-round-xl overflow-hidden container"><img src="https://images.unsplash.com/photo-1604514288114-3851479df2f2?q=80&amp;w=2071&amp;auto=format&amp;fit=crop&amp;ixlib=rb-4.0.3&amp;ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="w-full centered opacity-100"><div class="w-full h-22rem centered opacity-50" style="${ssrRenderStyle({ "background-color": "black" })}"></div><div class="text-7xl centered">${ssrInterpolate(unref(selectedEvent).eventName)}</div></div></div>`);
      _push(ssrRenderComponent(_component_Fieldset, {
        legend: "Event Details",
        class: "mx-2 mt-4 text-white bg-transparent border-round-xl"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p class="m-0"${_scopeId}> Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham. </p>`);
          } else {
            return [
              createVNode("p", { class: "m-0" }, ' Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham. ')
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="grid mt-4 mx-2 border-round-xl border-1"><div class="col-12 md:col-6 lg:col-6 border-round-xl font-bold"><div class="flex justify-content-center flex-wrap"><div class="flex align-items-center justify-content-center"><i class="pi pi-calendar text-white text-center" style="${ssrRenderStyle({ "font-size": "3rem" })}"></i></div><div class="flex align-items-center justify-content-center"><p class="text-center text-2xl p-3">${ssrInterpolate(getDate(unref(selectedEvent).eventStartDate))}</p></div></div></div><div class="col-12 md:col-6 lg:col-6 border-round-xl font-bold"><div class="flex justify-content-center flex-wrap"><div class="flex align-items-center justify-content-center"><i class="pi pi-clock text-white text-center" style="${ssrRenderStyle({ "font-size": "3rem" })}"></i></div><div class="flex align-items-center justify-content-center"><p class="text-center text-2xl p-3">${ssrInterpolate(getTime(unref(selectedEvent).eventStartDate))}</p></div></div></div></div><div class="grid mt-4 px-2"><!--[-->`);
      ssrRenderList(unref(selectedEvent).categoryList, (category) => {
        _push(`<div class="lg:col-4 col-12 p-2">`);
        _push(ssrRenderComponent(_component_Card, {
          style: { "overflow": "hidden" },
          class: "bg-gray-800 w-full"
        }, {
          title: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="text-white text-center"${_scopeId}>${ssrInterpolate(category.categoryName)}</div>`);
            } else {
              return [
                createVNode("div", { class: "text-white text-center" }, toDisplayString(category.categoryName), 1)
              ];
            }
          }),
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="text-white text-center"${_scopeId}>${ssrInterpolate(category.categoryDescription)}</div>`);
            } else {
              return [
                createVNode("div", { class: "text-white text-center" }, toDisplayString(category.categoryDescription), 1)
              ];
            }
          }),
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="p-2 border-round-xl text-center font-bold text-3xl" style="${ssrRenderStyle({ "background-color": "#FBAF44", "color": "black" })}"${_scopeId}> \u09F3${ssrInterpolate(category.categoryPrice)}</div>`);
            } else {
              return [
                createVNode("div", {
                  class: "p-2 border-round-xl text-center font-bold text-3xl",
                  style: { "background-color": "#FBAF44", "color": "black" }
                }, " \u09F3" + toDisplayString(category.categoryPrice), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div><div class="text-center mb-8 mx-2">`);
      _push(ssrRenderComponent(_component_GlobalButton, {
        title: "Purchase Ticket",
        onButtonTapped: ($event) => ("navigateTo" in _ctx ? _ctx.navigateTo : unref(navigateTo))("/checkout/" + unref(selectedEvent).eventId),
        class: "my-6 py-3 w-12 lg:w-4 font-bold",
        style: { "color": "black", "font-weight": "800" }
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/events/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_id_-qQhPWoZf.mjs.map
