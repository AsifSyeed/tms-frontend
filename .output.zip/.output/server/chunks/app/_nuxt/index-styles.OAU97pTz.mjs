const index_vue_vue_type_style_index_0_lang = ".soldOutButton{background-color:#b00020!important}a{text-decoration:none}";

const indexStyles_OAU97pTz = [index_vue_vue_type_style_index_0_lang, index_vue_vue_type_style_index_0_lang];

export { indexStyles_OAU97pTz as default };
//# sourceMappingURL=index-styles.OAU97pTz.mjs.map
