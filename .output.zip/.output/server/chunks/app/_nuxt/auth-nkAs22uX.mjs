import { d as defineNuxtRouteMiddleware, n as navigateTo } from '../server.mjs';
import { u as useCookie } from './cookie-T_RBG1b7.mjs';
import { i as isAuthenticatedState } from './state-J8LcOMay.mjs';
import 'vue';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue/server-renderer';
import './ssr-OTkz--jL.mjs';

const auth = defineNuxtRouteMiddleware((to, from) => {
  if (to.path === "/auth/logout") {
    console.log("inside path if");
    const token = useCookie("userToken");
    token.value = null;
    console.log(token);
    const isAuthenticated = isAuthenticatedState();
    isAuthenticated.value = false;
    return navigateTo(from);
  }
  if (to.path.includes("/checkout")) {
    const token = useCookie("userToken").value;
    console.log(token);
    if (!token) {
      return navigateTo("/auth/signin");
    }
  }
});

export { auth as default };
//# sourceMappingURL=auth-nkAs22uX.mjs.map
