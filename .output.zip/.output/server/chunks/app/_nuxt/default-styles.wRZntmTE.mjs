const default_vue_vue_type_style_index_0_lang = ".p-menuitem{margin:0 8px!important;padding:0}.p-menuitem-content{padding:8px 0!important;text-decoration-color:#fff!important}.p-focus{background-color:transparent;background:transparent}.p-menuitem-content:hover{background-color:#fbaf44}.p-menubar .p-menuitem:not(.p-highlight):not(.p-disabled).p-focus>.p-menuitem-content,.p-menuitem .p-menubar-root-list>.p-menuitem:not(.p-highlight):not(.p-disabled)>.p-menuitem-content:hover{background-color:transparent;background:transparent}.router-link-active{background-color:#fbaf44;border-radius:5px;margin:0;padding:8px}a{text-decoration:none}";

const defaultStyles_wRZntmTE = [default_vue_vue_type_style_index_0_lang, default_vue_vue_type_style_index_0_lang];

export { defaultStyles_wRZntmTE as default };
//# sourceMappingURL=default-styles.wRZntmTE.mjs.map
