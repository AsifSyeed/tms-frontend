import { _ as __nuxt_component_1 } from './InputText-yFaAcUG8.mjs';
import { _ as __nuxt_component_2 } from './Button-0cjZoXcA.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-qBDOgvys.mjs';
import { useSSRContext, defineComponent, ref, mergeProps, unref, isRef, withCtx, createTextVNode } from 'vue';
import { u as useFetch } from './fetch-h0nM2QUj.mjs';
import { u as useCookie } from './cookie-T_RBG1b7.mjs';
import { _ as _export_sfc, n as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0 } from './Logo_new-j6ubQB7j.mjs';
import { i as isAuthenticatedState } from './state-J8LcOMay.mjs';
import './inputtext.esm-uz5caPRi.mjs';
import './basecomponent.esm-Ns9gWp1a.mjs';
import './button.esm-yqH_VtjC.mjs';
import './badge.esm-qf1cCx9u.mjs';
import './index.esm-6y1nd5QS.mjs';
import './baseicon.esm-NKYSbA-x.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './ssr-OTkz--jL.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "signin",
  __ssrInlineRender: true,
  setup(__props) {
    const email = ref(null);
    const password = ref(null);
    const handleButtonTap = () => {
      onSubmit();
    };
    const onSubmit = async () => {
      const { data: responseData } = await useFetch("http://ec2-18-205-246-50.compute-1.amazonaws.com:8080/api/v1/auth/token", {
        method: "post",
        body: {
          email: email.value,
          password: password.value,
          userRole: 1
        }
      }, "$xHW4EsHrUl");
      console.log(responseData);
      if (responseData.value.responseCode === 200) {
        const userToken = useCookie("userToken");
        userToken.value = responseData.value.data.token;
        console.log("from cookieeee");
        console.log(userToken.value);
        const isAuthenticated = isAuthenticatedState();
        isAuthenticated.value = true;
        navigateTo("/");
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GlobalInputText = __nuxt_component_1;
      const _component_GlobalButton = __nuxt_component_2;
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "flex flex-column flex-wrap justify-content-center align-content-center align-items-center",
        style: { "height": "100%", "min-height": "98vh" }
      }, _attrs))} data-v-56a9017d><img${ssrRenderAttr("src", _imports_0)} alt="" class="max-w-18rem mb-5" data-v-56a9017d><div class="card flex flex-column p-7 bg-white border-round shadow-2 mb-7" style="${ssrRenderStyle({ "height": "30%", "width": "20%" })}" data-v-56a9017d>`);
      _push(ssrRenderComponent(_component_GlobalInputText, {
        type: "text",
        modelValue: unref(email),
        "onUpdate:modelValue": ($event) => isRef(email) ? email.value = $event : null,
        placeholder: "Email",
        class: "w-full mb-2 border-round"
      }, null, _parent));
      _push(ssrRenderComponent(_component_GlobalInputText, {
        type: "password",
        modelValue: unref(password),
        "onUpdate:modelValue": ($event) => isRef(password) ? password.value = $event : null,
        placeholder: "Password",
        class: "w-full mb-4 border-round"
      }, null, _parent));
      _push(ssrRenderComponent(_component_GlobalButton, {
        onButtonTapped: handleButtonTap,
        title: "Sign In",
        disabled: false
      }, null, _parent));
      _push(`<div class="w-full text-center pt-4" data-v-56a9017d>Not signed up yet? `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "signupLink font-bold",
        to: "/auth/signup"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sign Up`);
          } else {
            return [
              createTextVNode("Sign Up")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/auth/signin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const signin = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-56a9017d"]]);

export { signin as default };
//# sourceMappingURL=signin-TmfJOIy5.mjs.map
