const signup_vue_vue_type_style_index_0_scoped_bc957227_lang = ".signupLink[data-v-bc957227]{text-decoration-color:#fbaf44}a[data-v-bc957227],a[data-v-bc957227]:active,a[data-v-bc957227]:hover,a[data-v-bc957227]:visited{color:#fbaf44}";

const signupStyles_iKaNuLxA = [signup_vue_vue_type_style_index_0_scoped_bc957227_lang, signup_vue_vue_type_style_index_0_scoped_bc957227_lang];

export { signupStyles_iKaNuLxA as default };
//# sourceMappingURL=signup-styles.iKaNuLxA.mjs.map
