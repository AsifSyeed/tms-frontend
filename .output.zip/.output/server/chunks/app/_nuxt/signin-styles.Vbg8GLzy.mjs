const signin_vue_vue_type_style_index_0_scoped_56a9017d_lang = ".signupLink[data-v-56a9017d]{text-decoration-color:#fbaf44}a[data-v-56a9017d],a[data-v-56a9017d]:active,a[data-v-56a9017d]:hover,a[data-v-56a9017d]:visited{color:#fbaf44}";

const signinStyles_Vbg8GLzy = [signin_vue_vue_type_style_index_0_scoped_56a9017d_lang, signin_vue_vue_type_style_index_0_scoped_56a9017d_lang];

export { signinStyles_Vbg8GLzy as default };
//# sourceMappingURL=signin-styles.Vbg8GLzy.mjs.map
