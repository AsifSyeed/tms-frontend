import { s as script } from './dropdown.esm-DN42yKgC.mjs';
import { _ as __nuxt_component_1 } from './InputText-yFaAcUG8.mjs';
import { _ as __nuxt_component_2 } from './Button-0cjZoXcA.mjs';
import { withAsyncContext, ref, mergeProps, unref, isRef, withCtx, openBlock, createBlock, createVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-h0nM2QUj.mjs';
import { u as useCookie } from './cookie-T_RBG1b7.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './baseicon.esm-NKYSbA-x.mjs';
import './basecomponent.esm-Ns9gWp1a.mjs';
import './index.esm-gqguK91M.mjs';
import './index.esm-61ytLCK9.mjs';
import './index.esm-6y1nd5QS.mjs';
import './index.esm-2XX5KkdH.mjs';
import './overlayeventbus.esm-9zDOutdg.mjs';
import './portal.esm-GQNjR_5n.mjs';
import './virtualscroller.esm-n_RolpYt.mjs';
import './inputtext.esm-uz5caPRi.mjs';
import './button.esm-yqH_VtjC.mjs';
import './badge.esm-qf1cCx9u.mjs';
import './ssr-OTkz--jL.mjs';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { data: events } = ([__temp, __restore] = withAsyncContext(() => useFetch("http://ec2-18-205-246-50.compute-1.amazonaws.com:8080/api/v1/event/all", "$p4EDjr24WS")), __temp = await __temp, __restore(), __temp);
    const selectedEvent = ref();
    const selectedCategory = ref();
    const numberOfTickets = ref(1);
    const numberOfTicketsOpttions = ref([
      { name: "1", value: 1 },
      { name: "2", value: 2 },
      { name: "3", value: 3 },
      { name: "4", value: 4 }
    ]);
    ref({
      eventCapacity: null,
      eventEndDate: "",
      eventName: "",
      eventStartDate: ""
    });
    const attendeeList = ref([
      {
        ticketOwnerEmail: "",
        ticketOwnerName: "",
        ticketOwnerNumber: ""
      }
    ]);
    let totalPrice = ref(0);
    const updateAttendeeCount = () => {
      attendeeList.value = [];
      for (let i = 0; i < numberOfTickets.value; i++) {
        const newAttendee = {
          ticketOwnerEmail: "",
          ticketOwnerName: "",
          ticketOwnerNumber: ""
        };
        attendeeList.value.push(newAttendee);
      }
      console.log(numberOfTickets.value);
      console.log(selectedEvent.value.eventName);
      console.log(selectedCategory.value);
      updateTotalPrice();
    };
    const updateTotalPrice = () => {
      if (selectedCategory.value) {
        console.log(selectedCategory.value.categoryPrice);
        console.log(numberOfTickets.value);
        totalPrice = selectedCategory.value.categoryPrice * numberOfTickets.value;
      } else {
        totalPrice = 0;
      }
    };
    const changedEvent = () => {
      selectedCategory.value = null;
      updateTotalPrice();
    };
    const purchaseTicket = async () => {
      const eventData = {
        eventId: selectedEvent.value.eventId,
        ticketCategory: selectedCategory.value.categoryId,
        ticketOwnerInformation: attendeeList.value
      };
      const userToken = useCookie("userToken");
      const token = "Bearer " + userToken.value;
      console.log(token);
      console.log(eventData);
      const { data: responseData } = await useFetch("http://ec2-18-205-246-50.compute-1.amazonaws.com:8080/api/v1/ticket/buy", {
        headers: {
          "Authorization": token
        },
        method: "post",
        body: eventData
      }, "$ZYW6wMWVDT");
      console.log(responseData);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Dropdown = script;
      const _component_GlobalInputText = __nuxt_component_1;
      const _component_GlobalButton = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full p-1" }, _attrs))}><div class="flex justify-content-center flex-wrap"><h2 class="text-4xl font-bold text-white">Checkout</h2></div><div class="formgrid grid bg-gray-800 p-3 border-round pt-4 mx-1"><div class="field col-12 md:col-5"><label class="text-white">Event</label>`);
      _push(ssrRenderComponent(_component_Dropdown, {
        modelValue: unref(selectedEvent),
        "onUpdate:modelValue": ($event) => isRef(selectedEvent) ? selectedEvent.value = $event : null,
        options: unref(events).data,
        optionLabel: "eventName",
        placeholder: "Select Event",
        class: "w-full bg-white",
        onChange: changedEvent
      }, null, _parent));
      _push(`</div><div class="field col-12 md:col-5"><label class="text-white">Ticket Category</label>`);
      _push(ssrRenderComponent(_component_Dropdown, {
        modelValue: unref(selectedCategory),
        "onUpdate:modelValue": ($event) => isRef(selectedCategory) ? selectedCategory.value = $event : null,
        options: unref(selectedEvent) ? unref(selectedEvent).categoryList : [],
        optionLabel: "categoryName",
        placeholder: "Select Category",
        class: "w-full bg-white",
        onChange: updateTotalPrice
      }, {
        value: withCtx((slotProps, _push2, _parent2, _scopeId) => {
          if (_push2) {
            if (slotProps.value) {
              _push2(`<div class="flex align-items-center"${_scopeId}><div class="flex align-items-center"${_scopeId}><div${_scopeId}>${ssrInterpolate(slotProps.value.categoryName)} - \u09F3${ssrInterpolate(slotProps.value.categoryPrice)}</div></div></div>`);
            } else {
              _push2(`<span${_scopeId}>${ssrInterpolate(slotProps.placeholder)}</span>`);
            }
          } else {
            return [
              slotProps.value ? (openBlock(), createBlock("div", {
                key: 0,
                class: "flex align-items-center"
              }, [
                createVNode("div", { class: "flex align-items-center" }, [
                  createVNode("div", null, toDisplayString(slotProps.value.categoryName) + " - \u09F3" + toDisplayString(slotProps.value.categoryPrice), 1)
                ])
              ])) : (openBlock(), createBlock("span", { key: 1 }, toDisplayString(slotProps.placeholder), 1))
            ];
          }
        }),
        option: withCtx((slotProps, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex align-items-center"${_scopeId}><div${_scopeId}>${ssrInterpolate(slotProps.option.categoryName)} - \u09F3${ssrInterpolate(slotProps.option.categoryPrice)}</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex align-items-center" }, [
                createVNode("div", null, toDisplayString(slotProps.option.categoryName) + " - \u09F3" + toDisplayString(slotProps.option.categoryPrice), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="field col-12 md:col-2"><label class="text-white">Number of Tickets</label>`);
      _push(ssrRenderComponent(_component_Dropdown, {
        modelValue: unref(numberOfTickets),
        "onUpdate:modelValue": ($event) => isRef(numberOfTickets) ? numberOfTickets.value = $event : null,
        options: unref(numberOfTicketsOpttions),
        onChange: updateAttendeeCount,
        optionLabel: "name",
        optionValue: "value",
        class: "w-full bg-white"
      }, null, _parent));
      _push(`</div></div>`);
      if (unref(numberOfTickets) > 0) {
        _push(`<div class="formgrid grid bg-gray-800 p-3 border-round pt-2 mt-4 mx-1"><div class="field col-12 md:col-12 text-white"><h3>Attendee List</h3></div><!--[-->`);
        ssrRenderList(unref(attendeeList), (attendee, index) => {
          _push(`<!--[--><div class="field col-12 md:col-5">`);
          _push(ssrRenderComponent(_component_GlobalInputText, {
            placeholder: "Name of attendee: " + index,
            modelValue: attendee.ticketOwnerName,
            "onUpdate:modelValue": ($event) => attendee.ticketOwnerName = $event
          }, null, _parent));
          _push(`</div><div class="field col-12 md:col-4">`);
          _push(ssrRenderComponent(_component_GlobalInputText, {
            placeholder: "Email",
            modelValue: attendee.ticketOwnerEmail,
            "onUpdate:modelValue": ($event) => attendee.ticketOwnerEmail = $event
          }, null, _parent));
          _push(`</div><div class="field col-12 md:col-3">`);
          _push(ssrRenderComponent(_component_GlobalInputText, {
            placeholder: "Phone",
            modelValue: attendee.ticketOwnerNumber,
            "onUpdate:modelValue": ($event) => attendee.ticketOwnerNumber = $event
          }, null, _parent));
          _push(`</div><!--]-->`);
        });
        _push(`<!--]--><div class="field col-12 md:col-10"></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex justify-content-center flex-wrap"><div class="flex align-items-center justify-content-center mt-5 h-3rem"><div class="border-round text-4xl font-bold text-white">Total: \u09F3${ssrInterpolate(unref(totalPrice))}</div></div></div><div class="flex justify-content-center flex-wrap mb-6">`);
      _push(ssrRenderComponent(_component_GlobalButton, {
        title: "Purchase Tickets",
        class: "flex align-items-center justify-content-center mt-5 w-4 h-3rem",
        onButtonTapped: purchaseTicket
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/checkout/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-_FOpJgrL.mjs.map
