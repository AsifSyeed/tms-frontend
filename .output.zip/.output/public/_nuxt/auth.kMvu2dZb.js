import{_ as r,a2 as t}from"./entry.YHGcAQyi.js";const s={};function a(e,n){return t(e.$slots,"default")}const c=r(s,[["render",a]]);export{c as default};
