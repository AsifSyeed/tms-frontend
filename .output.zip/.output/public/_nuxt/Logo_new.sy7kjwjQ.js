import"./entry.YHGcAQyi.js";const e=""+new URL("Logo_new.lsCfgemm.png",import.meta.url).href;export{e as _};
